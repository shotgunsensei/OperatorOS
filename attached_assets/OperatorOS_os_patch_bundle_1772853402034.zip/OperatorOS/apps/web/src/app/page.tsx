'use client';

import { useEffect, useState } from 'react';
import WorkspacePanel from '@/components/WorkspacePanel';
import FileExplorer from '@/components/FileExplorer';
import Editor from '@/components/Editor';
import TerminalStream from '@/components/TerminalStream';
import PreviewPanel from '@/components/PreviewPanel';
import AgentPanel from '@/components/AgentPanel';
import PublishPanel from '@/components/PublishPanel';
import ProcessesPanel from '@/components/ProcessesPanel';
import ServicesPanel from '@/components/ServicesPanel';
import AutomationPanel from '@/components/AutomationPanel';
import SystemStatusBar from '@/components/SystemStatusBar';
import SystemNotifications from '@/components/SystemNotifications';
import { api, type Workspace } from '@/lib/api';

export default function Home() {
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [bottomTab, setBottomTab] = useState<'terminal' | 'processes' | 'services' | 'agent' | 'publish' | 'preview' | 'automation'>('terminal');
  const [workspace, setWorkspace] = useState<Workspace | null>(null);

  useEffect(() => {
    if (!workspaceId) {
      setWorkspace(null);
      return;
    }
    let active = true;
    const load = async () => {
      try {
        const data = await api.getWorkspace(workspaceId);
        if (active) setWorkspace(data);
      } catch {}
    };
    load();
    const timer = setInterval(load, 4000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [workspaceId]);

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 52px)', background: '#010409', color: '#c9d1d9' }}>
      <div style={{ width: 300, minWidth: 240, borderRight: '1px solid #21262d', display: 'flex', flexDirection: 'column' }}>
        <WorkspacePanel workspaceId={workspaceId} onSelect={setWorkspaceId} />
      </div>

      {workspaceId ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <SystemStatusBar workspace={workspace} />
            <div style={{ padding: 8, borderBottom: '1px solid #21262d' }}><SystemNotifications workspaceId={workspaceId} /></div>
          </div>

          <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
            <div style={{ width: 240, minWidth: 180, borderRight: '1px solid #21262d' }}>
              <FileExplorer workspaceId={workspaceId} onSelectFile={setSelectedFile} />
            </div>
            <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
              <div style={{ flex: 1, minHeight: 0 }}>
                <Editor workspaceId={workspaceId} selectedFile={selectedFile} />
              </div>

              <div style={{ height: '45%', minHeight: 220, borderTop: '1px solid #21262d', display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', borderBottom: '1px solid #21262d', overflowX: 'auto' }}>
                  {(['terminal', 'processes', 'services', 'agent', 'publish', 'preview', 'automation'] as const).map((tab) => (
                    <button key={tab} onClick={() => setBottomTab(tab)} style={{ padding: '8px 14px', whiteSpace: 'nowrap', background: bottomTab === tab ? '#0d1117' : 'transparent', border: 'none', borderBottom: bottomTab === tab ? '2px solid #58a6ff' : '2px solid transparent', color: bottomTab === tab ? '#c9d1d9' : '#8b949e', cursor: 'pointer', fontSize: 12, fontWeight: 700 }}>
                      {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                  ))}
                </div>
                <div style={{ flex: 1, minHeight: 0 }}>
                  {bottomTab === 'terminal' && <TerminalStream workspaceId={workspaceId} />}
                  {bottomTab === 'processes' && <ProcessesPanel workspaceId={workspaceId} />}
                  {bottomTab === 'services' && <ServicesPanel workspaceId={workspaceId} />}
                  {bottomTab === 'agent' && <AgentPanel workspaceId={workspaceId} />}
                  {bottomTab === 'publish' && <PublishPanel workspaceId={workspaceId} />}
                  {bottomTab === 'preview' && <PreviewPanel workspaceId={workspaceId} />}
                  {bottomTab === 'automation' && <AutomationPanel workspaceId={workspaceId} />}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 24 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 42, fontWeight: 900, letterSpacing: '-0.06em', marginBottom: 10 }}>OperatorOS</div>
            <div style={{ fontSize: 16, color: '#8b949e', marginBottom: 8 }}>An app builder grows up and starts acting like an operating system.</div>
            <div style={{ fontSize: 13, color: '#6e7681' }}>Create or select a workspace to unlock files, services, processes, automation, and publish controls.</div>
          </div>
        </div>
      )}
    </div>
  );
}
